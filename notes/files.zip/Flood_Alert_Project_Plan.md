# Flood Alert & Monitoring System - Complete Project Plan

**Developer:** Thiwanka Lakshan  
**Timeline:** 8 Weeks (Nov 2025 - Jan 2026)  
**Type:** Software Engineering Project Assessment  
**Tech Stack:** Node.js, Express, PostgreSQL/PostGIS, React, Leaflet

---

## PROJECT OVERVIEW

### Problem Statement
Western Province, Sri Lanka faces recurring flood disasters affecting 294,000+ residents. Current warning systems lack real-time monitoring and automated alerts at the neighborhood level.

### Solution
A real-time flood monitoring and alert system that:
- Monitors weather conditions 24/7
- Calculates flood risk using rule-based assessment
- Sends automated SMS/email alerts
- Provides interactive map visualization
- Tracks historical patterns

### Key Differentiators
- Rule-based (no ML required - achievable in timeline)
- Real-time automated monitoring
- Neighborhood-level risk assessment
- Public web interface
- SMS/Email alert integration

---

## SYSTEM ARCHITECTURE

```
┌─────────────────┐
│   Weather APIs  │
│  (OpenWeather)  │
└────────┬────────┘
         │
         ▼
┌─────────────────────────┐
│   Backend (Node.js)     │
│  ┌──────────────────┐   │
│  │ Data Collection  │   │
│  │   (Cron Jobs)    │   │
│  └────────┬─────────┘   │
│           │              │
│  ┌────────▼─────────┐   │
│  │  Risk Calculator │   │
│  │  (Rule Engine)   │   │
│  └────────┬─────────┘   │
│           │              │
│  ┌────────▼─────────┐   │
│  │  Alert Manager   │   │
│  │  (SMS/Email)     │   │
│  └──────────────────┘   │
│           │              │
│  ┌────────▼─────────┐   │
│  │   REST API       │   │
│  │   (Express)      │   │
│  └──────────────────┘   │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│    PostgreSQL + PostGIS │
│  ┌──────────────────┐   │
│  │ Locations        │   │
│  │ Weather Data     │   │
│  │ Alerts History   │   │
│  │ Risk Assessments │   │
│  └──────────────────┘   │
└─────────────────────────┘
            │
            ▼
┌─────────────────────────┐
│   Frontend (React)      │
│  ┌──────────────────┐   │
│  │  Dashboard       │   │
│  │  Map View        │   │
│  │  Charts          │   │
│  │  Admin Panel     │   │
│  └──────────────────┘   │
└─────────────────────────┘
```

---

## TECHNOLOGY STACK

### Backend
- **Runtime:** Node.js 18+
- **Framework:** Express.js 4.x
- **Database:** PostgreSQL 15+ with PostGIS extension
- **ORM:** Sequelize or raw SQL
- **Scheduling:** node-cron
- **HTTP Client:** axios
- **Authentication:** JWT (for admin panel)
- **Validation:** Joi or express-validator
- **Testing:** Jest + Supertest

### Frontend
- **Framework:** React 18+
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Maps:** Leaflet.js + React-Leaflet
- **Charts:** Chart.js + react-chartjs-2
- **HTTP Client:** axios
- **State Management:** React Context API (keep it simple)
- **Routing:** React Router v6

### APIs & Services
- **Weather Data:** OpenWeatherMap API (Free tier: 1000 calls/day)
- **SMS Alerts:** Twilio (trial) or Dialog SMS API (Sri Lanka)
- **Email Alerts:** Nodemailer with Gmail SMTP
- **Historical Data:** NASA POWER API (free)

### Deployment
- **Backend:** Railway (free tier) or Render
- **Frontend:** Vercel or Netlify (free)
- **Database:** Railway PostgreSQL or Neon.tech
- **Version Control:** GitHub
- **CI/CD:** GitHub Actions (optional)

---

## DATABASE SCHEMA

### Tables

#### 1. locations
```sql
CREATE TABLE locations (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  district VARCHAR(100) NOT NULL, -- Colombo, Gampaha, Kalutara
  gn_division VARCHAR(255), -- Grama Niladhari division
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  elevation INTEGER, -- meters above sea level
  population INTEGER,
  geom GEOMETRY(Point, 4326), -- PostGIS geometry
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PostGIS index for spatial queries
CREATE INDEX idx_locations_geom ON locations USING GIST(geom);
```

#### 2. weather_data
```sql
CREATE TABLE weather_data (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  timestamp TIMESTAMP NOT NULL,
  temperature DECIMAL(5, 2), -- Celsius
  humidity INTEGER, -- Percentage
  rainfall_1h DECIMAL(6, 2), -- mm
  rainfall_24h DECIMAL(6, 2), -- mm (calculated)
  rainfall_72h DECIMAL(6, 2), -- mm (calculated)
  wind_speed DECIMAL(5, 2), -- m/s
  pressure INTEGER, -- hPa
  weather_condition VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_weather_location_time ON weather_data(location_id, timestamp DESC);
```

#### 3. risk_assessments
```sql
CREATE TABLE risk_assessments (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  timestamp TIMESTAMP NOT NULL,
  risk_level VARCHAR(20) NOT NULL, -- LOW, MODERATE, HIGH, CRITICAL
  risk_score INTEGER NOT NULL, -- 0-10
  factors JSONB, -- Store calculation factors
  rainfall_24h DECIMAL(6, 2),
  rainfall_72h DECIMAL(6, 2),
  elevation_factor INTEGER,
  season_factor INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_risk_location_time ON risk_assessments(location_id, timestamp DESC);
```

#### 4. alerts
```sql
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  risk_assessment_id INTEGER REFERENCES risk_assessments(id),
  alert_type VARCHAR(20) NOT NULL, -- SMS, EMAIL
  recipient VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL, -- PENDING, SENT, FAILED
  sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_alerts_status ON alerts(status, created_at);
```

#### 5. alert_subscriptions
```sql
CREATE TABLE alert_subscriptions (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  phone_number VARCHAR(20),
  email VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  min_risk_level VARCHAR(20) DEFAULT 'MODERATE', -- Only alert if risk >= this
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 6. historical_floods
```sql
CREATE TABLE historical_floods (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  flood_date DATE NOT NULL,
  severity VARCHAR(20), -- MINOR, MODERATE, SEVERE, CATASTROPHIC
  casualties INTEGER DEFAULT 0,
  affected_population INTEGER,
  damage_estimate DECIMAL(12, 2), -- LKR
  description TEXT,
  source VARCHAR(255), -- Data source
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 7. system_logs
```sql
CREATE TABLE system_logs (
  id SERIAL PRIMARY KEY,
  log_type VARCHAR(50) NOT NULL, -- API_CALL, CALCULATION, ALERT, ERROR
  message TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_logs_type_time ON system_logs(log_type, created_at DESC);
```

---

## RISK CALCULATION ALGORITHM

### Rule-Based Risk Scoring

```javascript
// config/riskRules.js
module.exports = {
  rainfall: {
    rainfall24h: [
      { min: 200, score: 4, label: 'Extreme 24h rainfall' },
      { min: 150, score: 3, label: 'Very heavy 24h rainfall' },
      { min: 100, score: 2, label: 'Heavy 24h rainfall' },
      { min: 50, score: 1, label: 'Moderate 24h rainfall' }
    ],
    rainfall72h: [
      { min: 400, score: 4, label: 'Extreme 72h rainfall' },
      { min: 300, score: 3, label: 'Very heavy 72h rainfall' },
      { min: 200, score: 2, label: 'Heavy 72h rainfall' },
      { min: 100, score: 1, label: 'Moderate 72h rainfall' }
    ]
  },
  
  elevation: [
    { max: 5, score: 3, label: 'Extremely low elevation' },
    { max: 10, score: 2, label: 'Very low elevation' },
    { max: 25, score: 1, label: 'Low elevation' }
  ],
  
  season: [
    { months: [5, 6, 7, 8, 9], score: 2, label: 'SW Monsoon season' },
    { months: [10, 11, 12, 1], score: 2, label: 'NE Monsoon season' },
    { months: [3, 4], score: 1, label: 'Inter-monsoon period' }
  ],
  
  historicalFlood: [
    { floodsLast5Years: 3, score: 2, label: 'Frequently flooded area' },
    { floodsLast5Years: 1, score: 1, label: 'Previously flooded area' }
  ],
  
  riskLevels: [
    { minScore: 9, level: 'CRITICAL', color: '#DC2626', action: 'Evacuate immediately' },
    { minScore: 6, level: 'HIGH', color: '#F97316', action: 'Prepare to evacuate' },
    { minScore: 3, level: 'MODERATE', color: '#EAB308', action: 'Stay alert, monitor updates' },
    { minScore: 0, level: 'LOW', color: '#22C55E', action: 'Normal conditions' }
  ]
};
```

### Risk Calculation Function

```javascript
// services/riskCalculator.js
const riskRules = require('../config/riskRules');

class RiskCalculator {
  calculateRisk(location, weatherData, historicalFloods) {
    let totalScore = 0;
    const factors = [];
    
    // Factor 1: 24-hour rainfall
    const rainfall24hScore = this.calculateRainfallScore(
      weatherData.rainfall_24h,
      riskRules.rainfall.rainfall24h
    );
    if (rainfall24hScore.score > 0) {
      totalScore += rainfall24hScore.score;
      factors.push(rainfall24hScore);
    }
    
    // Factor 2: 72-hour rainfall
    const rainfall72hScore = this.calculateRainfallScore(
      weatherData.rainfall_72h,
      riskRules.rainfall.rainfall72h
    );
    if (rainfall72hScore.score > 0) {
      totalScore += rainfall72hScore.score;
      factors.push(rainfall72hScore);
    }
    
    // Factor 3: Elevation
    const elevationScore = this.calculateElevationScore(
      location.elevation,
      riskRules.elevation
    );
    if (elevationScore.score > 0) {
      totalScore += elevationScore.score;
      factors.push(elevationScore);
    }
    
    // Factor 4: Season
    const seasonScore = this.calculateSeasonScore(
      new Date(),
      riskRules.season
    );
    if (seasonScore.score > 0) {
      totalScore += seasonScore.score;
      factors.push(seasonScore);
    }
    
    // Factor 5: Historical flood frequency
    const historicalScore = this.calculateHistoricalScore(
      historicalFloods,
      riskRules.historicalFlood
    );
    if (historicalScore.score > 0) {
      totalScore += historicalScore.score;
      factors.push(historicalScore);
    }
    
    // Determine risk level
    const riskLevel = this.getRiskLevel(totalScore, riskRules.riskLevels);
    
    return {
      riskScore: totalScore,
      riskLevel: riskLevel.level,
      riskColor: riskLevel.color,
      recommendedAction: riskLevel.action,
      factors: factors
    };
  }
  
  calculateRainfallScore(rainfall, rules) {
    for (const rule of rules) {
      if (rainfall >= rule.min) {
        return {
          factor: 'rainfall',
          value: rainfall,
          score: rule.score,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  calculateElevationScore(elevation, rules) {
    for (const rule of rules) {
      if (elevation <= rule.max) {
        return {
          factor: 'elevation',
          value: elevation,
          score: rule.score,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  calculateSeasonScore(date, rules) {
    const month = date.getMonth() + 1; // 1-12
    for (const rule of rules) {
      if (rule.months.includes(month)) {
        return {
          factor: 'season',
          score: rule.score,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  calculateHistoricalScore(floods, rules) {
    const fiveYearsAgo = new Date();
    fiveYearsAgo.setFullYear(fiveYearsAgo.getFullYear() - 5);
    
    const recentFloods = floods.filter(f => new Date(f.flood_date) >= fiveYearsAgo);
    
    for (const rule of rules) {
      if (recentFloods.length >= rule.floodsLast5Years) {
        return {
          factor: 'historical',
          value: recentFloods.length,
          score: rule.score,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  getRiskLevel(score, levels) {
    for (const level of levels) {
      if (score >= level.minScore) {
        return level;
      }
    }
    return levels[levels.length - 1]; // Default to lowest level
  }
}

module.exports = new RiskCalculator();
```

---

## API ENDPOINTS SPECIFICATION

### Public Endpoints

#### GET /api/locations
Get all monitored locations
```json
Response: [
  {
    "id": 1,
    "name": "Wellampitiya",
    "district": "Colombo",
    "gn_division": "Kolonnawa",
    "latitude": 6.9497,
    "longitude": 79.9258,
    "elevation": 3,
    "currentRisk": {
      "level": "MODERATE",
      "score": 4,
      "color": "#EAB308"
    }
  }
]
```

#### GET /api/locations/:id
Get specific location details
```json
Response: {
  "id": 1,
  "name": "Wellampitiya",
  "district": "Colombo",
  "currentWeather": {
    "temperature": 28.5,
    "humidity": 78,
    "rainfall_24h": 85.3,
    "timestamp": "2025-11-03T10:30:00Z"
  },
  "currentRisk": {
    "level": "MODERATE",
    "score": 4,
    "factors": [
      { "factor": "rainfall", "label": "Heavy 24h rainfall", "score": 2 },
      { "factor": "elevation", "label": "Extremely low elevation", "score": 3 }
    ],
    "recommendedAction": "Stay alert, monitor updates"
  }
}
```

#### GET /api/locations/:id/weather-history
Get weather history for charts
```json
Query params: ?period=7d (options: 24h, 7d, 30d)
Response: [
  {
    "timestamp": "2025-11-03T00:00:00Z",
    "rainfall_1h": 5.2,
    "temperature": 27.3,
    "humidity": 75
  }
]
```

#### GET /api/locations/:id/risk-history
Get risk assessment history
```json
Response: [
  {
    "timestamp": "2025-11-03T10:00:00Z",
    "riskLevel": "MODERATE",
    "riskScore": 4
  }
]
```

#### GET /api/dashboard/summary
Dashboard summary data
```json
Response: {
  "totalLocations": 25,
  "riskDistribution": {
    "CRITICAL": 0,
    "HIGH": 2,
    "MODERATE": 8,
    "LOW": 15
  },
  "activeAlerts": 5,
  "lastUpdate": "2025-11-03T10:30:00Z"
}
```

#### POST /api/subscriptions
Subscribe to alerts
```json
Request: {
  "locationId": 1,
  "phoneNumber": "+94771234567",
  "email": "user@example.com",
  "minRiskLevel": "MODERATE"
}
Response: {
  "id": 123,
  "message": "Subscription created successfully"
}
```

### Admin Endpoints (JWT Protected)

#### POST /api/admin/login
Admin login
```json
Request: {
  "username": "admin",
  "password": "secure_password"
}
Response: {
  "token": "jwt_token_here",
  "user": { "username": "admin" }
}
```

#### GET /api/admin/alerts
Get all alerts
```json
Response: [
  {
    "id": 1,
    "location": "Wellampitiya",
    "recipient": "+94771234567",
    "message": "MODERATE flood risk...",
    "status": "SENT",
    "sent_at": "2025-11-03T10:15:00Z"
  }
]
```

#### PUT /api/admin/risk-rules
Update risk calculation rules
```json
Request: {
  "rainfall": { /* updated rules */ },
  "elevation": { /* updated rules */ }
}
```

#### GET /api/admin/logs
System logs
```json
Query params: ?type=ERROR&limit=50
Response: [
  {
    "id": 1,
    "log_type": "API_CALL",
    "message": "OpenWeatherMap API called",
    "created_at": "2025-11-03T10:30:00Z"
  }
]
```

---

## 8-WEEK IMPLEMENTATION PLAN

### **WEEK 1: Backend Foundation** (Nov 4-10)

**Goals:** Database, basic API structure, weather data collection

**Day 1-2: Project Setup**
- [ ] Initialize Node.js project with Express
- [ ] Set up PostgreSQL database
- [ ] Install PostGIS extension
- [ ] Create database schema (all tables)
- [ ] Set up environment variables (.env file)
- [ ] Git repository initialization
- [ ] Basic Express server running

**Day 3-4: Weather API Integration**
- [ ] Sign up for OpenWeatherMap API (free tier)
- [ ] Create weather service module
- [ ] Implement API call to fetch current weather
- [ ] Store weather data in database
- [ ] Test with 2-3 locations in Western Province

**Day 5-7: Automated Data Collection**
- [ ] Install and configure node-cron
- [ ] Create scheduled job (every 30 minutes)
- [ ] Fetch weather for all locations
- [ ] Calculate 24h and 72h rainfall aggregates
- [ ] Error handling and logging
- [ ] Verify data is being collected properly

**Deliverables:**
- ✅ Working database with schema
- ✅ Express API running on localhost
- ✅ Weather data being collected every 30 mins
- ✅ Data visible in database

**Study This Week:**
- Express.js routing and middleware
- PostgreSQL queries
- Cron jobs in Node.js
- Axios for API calls

---

### **WEEK 2: Risk Calculation & Core API** (Nov 11-17)

**Goals:** Implement risk calculation logic, build REST API endpoints

**Day 1-2: Risk Calculator**
- [ ] Create risk calculation service
- [ ] Implement rule-based scoring (refer to algorithm above)
- [ ] Test with sample data
- [ ] Store risk assessments in database
- [ ] Integrate with weather collection (calculate after each update)

**Day 3-4: API Endpoints - Locations**
- [ ] GET /api/locations (list all)
- [ ] GET /api/locations/:id (single location)
- [ ] Include current risk in response
- [ ] Add pagination for locations list
- [ ] Test all endpoints with Postman

**Day 5-6: API Endpoints - Weather & Risk**
- [ ] GET /api/locations/:id/weather-history
- [ ] GET /api/locations/:id/risk-history
- [ ] GET /api/dashboard/summary
- [ ] Implement query filters (date ranges, periods)
- [ ] Add proper error responses

**Day 7: Testing & Documentation**
- [ ] Test all API endpoints
- [ ] Write API documentation (README or Postman collection)
- [ ] Add input validation (express-validator)
- [ ] Fix any bugs found

**Deliverables:**
- ✅ Risk calculation working
- ✅ Complete REST API for locations, weather, risk
- ✅ API documentation
- ✅ Risk assessments being calculated automatically

**Study This Week:**
- REST API best practices
- API documentation
- Error handling in Express
- SQL queries and joins

---

### **WEEK 3: React Basics & Frontend Setup** (Nov 18-24)

**Goals:** Learn React fundamentals, set up frontend project

**Day 1-3: React Learning**
- [ ] React crash course (YouTube: Traversy Media or Net Ninja)
- [ ] Understand: Components, Props, State, useEffect, useState
- [ ] Build practice todo app or similar
- [ ] Understand folder structure

**Day 4-5: Frontend Project Setup**
- [ ] Create React app with Vite
- [ ] Set up Tailwind CSS
- [ ] Install axios for API calls
- [ ] Install React Router for routing
- [ ] Create basic layout (Header, Footer, Main content area)
- [ ] Set up proxy to backend API

**Day 6-7: Dashboard Page - Basic**
- [ ] Create Dashboard component
- [ ] Fetch /api/dashboard/summary
- [ ] Display risk distribution (simple cards for now)
- [ ] Show total locations count
- [ ] Show last update time
- [ ] Basic responsive layout

**Deliverables:**
- ✅ React app running
- ✅ Basic dashboard showing API data
- ✅ Frontend connected to backend
- ✅ Understand React fundamentals

**Study This Week:**
- React fundamentals (components, hooks)
- Tailwind CSS utility classes
- Axios in React
- React Router basics

---

### **WEEK 4: Map Visualization** (Nov 25 - Dec 1)

**Goals:** Interactive map showing locations with risk colors

**Day 1-2: Leaflet Setup**
- [ ] Install Leaflet and react-leaflet
- [ ] Create Map component
- [ ] Display base map (OpenStreetMap)
- [ ] Center map on Western Province
- [ ] Add zoom controls

**Day 3-4: Location Markers**
- [ ] Fetch locations from API
- [ ] Add markers for each location
- [ ] Color markers by risk level (green/yellow/orange/red)
- [ ] Add tooltips showing location name
- [ ] Cluster markers if too many (optional)

**Day 5-6: Location Details Popup**
- [ ] Click marker to show popup
- [ ] Display location info in popup:
  - Name, district
  - Current temperature, rainfall
  - Risk level and score
  - Recommended action
- [ ] Style popup nicely

**Day 7: Map Polish**
- [ ] Add legend (risk level colors)
- [ ] Add map controls (zoom to location)
- [ ] Mobile responsive map
- [ ] Loading states
- [ ] Error handling

**Deliverables:**
- ✅ Interactive map with all locations
- ✅ Color-coded markers by risk
- ✅ Click markers to see details
- ✅ Mobile-friendly map

**Study This Week:**
- Leaflet.js documentation
- React-Leaflet examples
- GeoJSON basics
- Responsive map design

---

### **WEEK 5: Alert System Backend** (Dec 2-8)

**Goals:** SMS and email alert implementation

**Day 1-2: Email Alerts**
- [ ] Set up Nodemailer with Gmail
- [ ] Create email template for alerts
- [ ] Implement sendEmail function
- [ ] Test sending emails
- [ ] Store sent alerts in database

**Day 3-4: SMS Alerts**
- [ ] Choose SMS provider (Twilio trial OR Dialog SMS API)
- [ ] Sign up and get credentials
- [ ] Implement sendSMS function
- [ ] Test sending SMS
- [ ] Handle SMS provider errors

**Day 5-6: Alert Logic**
- [ ] Create alert service
- [ ] Trigger alerts when risk level changes
- [ ] Check subscriptions before sending
- [ ] Only alert if risk >= subscriber's min level
- [ ] Prevent duplicate alerts (don't spam)
- [ ] Log all alert attempts

**Day 7: Alert Management API**
- [ ] POST /api/subscriptions (subscribe)
- [ ] DELETE /api/subscriptions/:id (unsubscribe)
- [ ] GET /api/subscriptions (list user's subscriptions)
- [ ] Validate phone numbers and emails
- [ ] Test entire alert flow

**Deliverables:**
- ✅ Email alerts working
- ✅ SMS alerts working
- ✅ Alert subscriptions system
- ✅ Alerts trigger on risk level changes

**Study This Week:**
- Nodemailer documentation
- Twilio/Dialog SMS API docs
- Email/SMS best practices
- Rate limiting

---

### **WEEK 6: Charts & Historical Data** (Dec 9-15)

**Goals:** Rainfall graphs and historical flood data visualization

**Day 1-2: Chart Setup**
- [ ] Install Chart.js and react-chartjs-2
- [ ] Create Chart component
- [ ] Fetch weather history from API
- [ ] Display 24h rainfall chart (line graph)
- [ ] Style chart with Tailwind

**Day 3-4: Multiple Charts**
- [ ] 7-day rainfall chart
- [ ] 30-day rainfall chart
- [ ] Temperature chart (optional)
- [ ] Add chart selector/tabs
- [ ] Responsive charts

**Day 5-6: Historical Floods Display**
- [ ] Seed historical flood data (2016, 2017, 2024 events)
- [ ] Create API endpoint for historical floods
- [ ] Display flood history timeline
- [ ] Show flood markers on charts
- [ ] Add flood event details modal

**Day 7: Location Detail Page**
- [ ] Create detailed page for each location
- [ ] Route: /location/:id
- [ ] Show all info: weather, risk, charts, history
- [ ] Navigation from map popup to detail page
- [ ] Back to map button

**Deliverables:**
- ✅ Interactive rainfall charts
- ✅ Historical flood data displayed
- ✅ Location detail pages
- ✅ Complete user flow from map to details

**Study This Week:**
- Chart.js documentation
- React Router navigation
- Data visualization best practices
- Timeline components

---

### **WEEK 7: Admin Panel & Polish** (Dec 16-22)

**Goals:** Admin dashboard, UI polish, mobile responsiveness

**Day 1-2: Admin Authentication**
- [ ] Create admin user in database
- [ ] Implement JWT authentication
- [ ] POST /api/admin/login endpoint
- [ ] Admin login page (React)
- [ ] Protect admin routes (middleware)
- [ ] Store JWT in localStorage

**Day 3-4: Admin Dashboard**
- [ ] Admin layout component
- [ ] Dashboard showing:
  - Total alerts sent today
  - System status
  - Recent logs
  - Alert queue status
- [ ] GET /api/admin/alerts endpoint
- [ ] Display alerts table with filters
- [ ] View alert details

**Day 5-6: UI Polish**
- [ ] Improve overall design consistency
- [ ] Add loading spinners everywhere
- [ ] Better error messages
- [ ] Add empty states ("No data yet")
- [ ] Improve mobile responsiveness
- [ ] Add transitions/animations
- [ ] Test on different screen sizes

**Day 7: Testing & Bug Fixes**
- [ ] Full system testing
- [ ] Test on mobile devices
- [ ] Fix any bugs found
- [ ] Performance optimization
- [ ] Code cleanup

**Deliverables:**
- ✅ Admin panel with login
- ✅ Alert management interface
- ✅ Polished, responsive UI
- ✅ Bug-free system

**Study This Week:**
- JWT authentication
- Protected routes in React
- Mobile-first design
- UI/UX best practices

---

### **WEEK 8: Deployment & Documentation** (Dec 23-29)

**Goals:** Deploy to production, write documentation, prepare presentation

**Day 1-2: Backend Deployment**
- [ ] Sign up for Railway or Render
- [ ] Create PostgreSQL database on Railway
- [ ] Deploy backend to Railway
- [ ] Set environment variables
- [ ] Test API endpoints in production
- [ ] Set up custom domain (optional)

**Day 3: Frontend Deployment**
- [ ] Sign up for Vercel
- [ ] Update API URLs to production backend
- [ ] Deploy frontend to Vercel
- [ ] Test entire app in production
- [ ] Fix CORS issues if any
- [ ] Custom domain (optional)

**Day 4-5: Documentation**
- [ ] README.md with:
  - Project overview
  - Features list
  - Tech stack
  - Installation instructions
  - API documentation
  - Screenshots
- [ ] Code comments cleanup
- [ ] User guide (how to use the system)
- [ ] Admin guide (how to manage)

**Day 6-7: Presentation Prep**
- [ ] Create presentation slides (PowerPoint/Google Slides)
- [ ] Slides: Problem → Solution → Architecture → Demo → Impact
- [ ] Prepare demo scenarios
- [ ] Record demo video (backup if live demo fails)
- [ ] Practice presentation
- [ ] Prepare for Q&A

**Deliverables:**
- ✅ Live production system
- ✅ Complete documentation
- ✅ Presentation ready
- ✅ Demo video

**Final Checklist:**
- [ ] System is live and working
- [ ] All code pushed to GitHub
- [ ] Documentation complete
- [ ] Presentation slides ready
- [ ] Demo rehearsed
- [ ] Backup plan if demo fails

---

## KEY LOCATIONS TO MONITOR

### Western Province - High Risk Areas

**Colombo District:**
1. Wellampitiya (Kolonnawa) - Elevation: ~3m
2. Kelanimulla (Kolonnawa) - Elevation: ~4m
3. Gotatuwa (Kolonnawa) - Elevation: ~5m
4. Malabe (Kaduwela) - Elevation: ~8m
5. Angoda (Kaduwela) - Elevation: ~6m
6. Kottikawatte (Borella) - Elevation: ~5m
7. Mattakkuliya - Elevation: ~2m
8. Grandpass - Elevation: ~3m

**Gampaha District:**
9. Gampaha town - Elevation: ~12m
10. Biyagama - Elevation: ~10m
11. Dompe - Elevation: ~18m
12. Jaela - Elevation: ~8m
13. Wattala - Elevation: ~4m
14. Kelaniya - Elevation: ~7m
15. Kiribathgoda - Elevation: ~15m

**Kalutara District:**
16. Kalutara town - Elevation: ~5m
17. Panadura - Elevation: ~3m
18. Horana - Elevation: ~12m
19. Wadduwa - Elevation: ~2m
20. Bandaragama - Elevation: ~8m

**Seed this data into your database on setup!**

---

## DEMO SCENARIOS

### Scenario 1: Normal Conditions
- Show map with all green markers
- Click a location, show LOW risk
- Display charts with normal rainfall

### Scenario 2: Rising Risk
- Manually update weather data (or wait for API)
- Show markers turning yellow/orange
- Demonstrate risk calculation in action
- Show factors contributing to risk

### Scenario 3: Critical Alert
- Set very high rainfall values (testing mode)
- Show red markers
- Demonstrate alert being triggered
- Show email/SMS sent (if possible during demo)
- Show admin panel with alert log

### Scenario 4: Historical Data
- Show charts with historical rainfall
- Point out 2024 flood event markers
- Show how current conditions compare

---

## TROUBLESHOOTING GUIDE

### Common Issues & Solutions

**Issue: OpenWeatherMap API not returning data**
- Check API key is correct in .env
- Verify you haven't exceeded free tier limit (1000 calls/day)
- Check latitude/longitude are correct
- Look at API response for error messages

**Issue: Database connection failed**
- Verify PostgreSQL is running
- Check connection string in .env
- Ensure database exists
- Check firewall settings

**Issue: CORS errors in frontend**
- Add CORS middleware in Express: `app.use(cors())`
- Check API URL in frontend is correct
- In production, configure CORS to allow your frontend domain

**Issue: SMS/Email not sending**
- Check provider credentials
- Verify you have credit (Twilio trial)
- Check internet connection
- Look at error logs
- Test with known working email/phone number

**Issue: Map not displaying**
- Check Leaflet CSS is imported
- Verify latitude/longitude data is valid
- Check browser console for errors
- Ensure map container has height in CSS

**Issue: Charts not showing**
- Verify data format matches Chart.js requirements
- Check if data array is empty
- Look at browser console for errors
- Ensure Chart.js is properly imported

---

## TECHNOLOGIES TO STUDY

### Week-by-Week Learning Plan

**Week 1:**
- Express.js basics
- PostgreSQL basics
- Node.js async/await
- Environment variables

**Week 2:**
- REST API design
- Postman for testing
- SQL joins and aggregations
- Error handling patterns

**Week 3:**
- React fundamentals
- JSX syntax
- React Hooks (useState, useEffect)
- Component lifecycle

**Week 4:**
- Leaflet.js documentation
- React-Leaflet
- GeoJSON format
- Map interactions

**Week 5:**
- Nodemailer setup
- SMS API integration
- Email templates
- Async messaging

**Week 6:**
- Chart.js
- Data visualization principles
- React Router
- State management

**Week 7:**
- JWT authentication
- Protected routes
- Admin interfaces
- UI/UX design

**Week 8:**
- Deployment platforms
- Environment configuration
- Documentation writing
- Presentation skills

---

## RESOURCES

### Documentation
- **Express.js:** https://expressjs.com/
- **React:** https://react.dev/
- **PostgreSQL:** https://www.postgresql.org/docs/
- **PostGIS:** https://postgis.net/documentation/
- **Leaflet:** https://leafletjs.com/
- **Chart.js:** https://www.chartjs.org/
- **Tailwind CSS:** https://tailwindcss.com/

### Tutorials
- **React Crash Course:** Traversy Media (YouTube)
- **Express.js Tutorial:** Net Ninja (YouTube)
- **PostgreSQL Basics:** freeCodeCamp (YouTube)
- **Leaflet Maps:** Leaflet official tutorials

### APIs
- **OpenWeatherMap:** https://openweathermap.org/api
- **NASA POWER:** https://power.larc.nasa.gov/
- **Twilio:** https://www.twilio.com/docs
- **Dialog SMS:** Contact Dialog Axiata for API docs

### Deployment
- **Railway:** https://railway.app/
- **Vercel:** https://vercel.com/
- **Render:** https://render.com/

---

## SUCCESS CRITERIA

### Minimum (Must Have) - Pass Grade
- [ ] Backend API with 5+ endpoints working
- [ ] Database with proper schema and relationships
- [ ] Weather data being collected automatically
- [ ] Risk calculation implemented and tested
- [ ] Basic frontend showing map and risk levels
- [ ] Deployed and accessible online
- [ ] Documentation (README)

### Target (Should Have) - Good Grade
- [ ] All minimum criteria PLUS:
- [ ] Alert system (email OR SMS) working
- [ ] Charts displaying historical data
- [ ] Admin panel with authentication
- [ ] Mobile responsive design
- [ ] 15+ locations monitored
- [ ] Comprehensive documentation
- [ ] Demo video

### Excellent (Could Have) - Top Grade
- [ ] All target criteria PLUS:
- [ ] Both email AND SMS alerts
- [ ] Advanced charts with multiple timeframes
- [ ] Historical flood data integration
- [ ] System logs and monitoring
- [ ] Clean, polished UI
- [ ] Research paper quality documentation
- [ ] Live demo that impresses

---

## CONTINGENCY PLANS

### If Running Behind Schedule

**Week 3 Behind:**
- Skip fancy React, use simpler HTML/CSS/Vanilla JS for frontend
- Focus on backend functionality

**Week 5 Behind:**
- Skip SMS, only do email alerts
- Or skip alerts entirely, focus on monitoring

**Week 6 Behind:**
- Skip multiple charts, just do one 7-day rainfall chart
- Skip historical floods

**Week 7 Behind:**
- Skip admin panel
- Basic UI without animations

**General Rule:**
Priority order:
1. Backend API (core)
2. Risk calculation (core)
3. Basic map display (core)
4. Charts (important)
5. Alerts (important)
6. Admin panel (nice to have)
7. Fancy UI (nice to have)

---

## FINAL NOTES

**Remember:**
- Commit to GitHub DAILY (shows consistent work)
- Test frequently (don't wait till end)
- Ask for help when stuck (StackOverflow, Discord, me!)
- Document as you go (not at the end)
- Keep it simple - working > perfect
- Demo on your laptop (don't rely on venue WiFi)

**This is achievable!** You have the skills, the plan, and the motivation. Stay disciplined, follow the weekly plan, and you'll have an impressive project by January.

**You got this, Thiwanka! 🚀**

---

*End of Project Plan*
