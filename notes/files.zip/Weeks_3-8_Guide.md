# WEEKS 3-8: COMPLETE IMPLEMENTATION GUIDES

This document contains detailed day-by-day instructions for Weeks 3 through 8 of your Flood Alert System project.

---

# WEEK 3: REACT BASICS & FRONTEND SETUP

**Goal:** Learn React, set up frontend project, create basic dashboard

## DAY 1-2: LEARN REACT FUNDAMENTALS (6-8 hours total)

### Learning Resources (Pick ONE):
1. **Net Ninja React Tutorial** (YouTube) - 3 hours
2. **Traversy Media React Crash Course** (YouTube) - 2 hours  
3. **React.dev Tutorial** (Official docs) - 3 hours

### Key Concepts to Master:
```javascript
// 1. Components
function Welcome() {
  return <h1>Hello!</h1>;
}

// 2. Props
function Greeting({ name }) {
  return <h1>Hello, {name}!</h1>;
}

// 3. State
import { useState } from 'react';
function Counter() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount(count + 1)}>
      Count: {count}
    </button>
  );
}

// 4. useEffect
import { useEffect } from 'react';
function DataFetcher() {
  useEffect(() => {
    // Fetch data when component loads
    fetchData();
  }, []); // Empty array = run once
}
```

### Practice Exercise:
Build a simple todo app to practice components, state, and props.

---

## DAY 3: FRONTEND PROJECT SETUP (3-4 hours)

### Step 1: Create React App

```bash
# Create new React project with Vite
npm create vite@latest flood-alert-frontend -- --template react

cd flood-alert-frontend
npm install
```

### Step 2: Install Dependencies

```bash
# Core dependencies
npm install axios react-router-dom

# Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### Step 3: Configure Tailwind

Update `tailwind.config.js`:
```javascript
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

Update `src/index.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

### Step 4: Set Up Proxy to Backend

Create `vite.config.js`:
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      }
    }
  }
})
```

### Step 5: Create Folder Structure

```bash
cd src
mkdir components pages services utils
touch services/api.js
```

### Step 6: Create API Service

Create `src/services/api.js`:
```javascript
import axios from 'axios';

const API_BASE_URL = '/api';

export const api = {
  // Locations
  getLocations: () => axios.get(`${API_BASE_URL}/locations`),
  getLocation: (id) => axios.get(`${API_BASE_URL}/locations/${id}`),
  
  // Weather
  getCurrentWeather: (locationId) => 
    axios.get(`${API_BASE_URL}/weather/${locationId}/current`),
  getWeatherHistory: (locationId, period = '7d') => 
    axios.get(`${API_BASE_URL}/weather/${locationId}/history?period=${period}`),
  
  // Risk
  getCurrentRisk: (locationId) => 
    axios.get(`${API_BASE_URL}/risk/${locationId}/current`),
  getRiskHistory: (locationId, period = '7d') => 
    axios.get(`${API_BASE_URL}/risk/${locationId}/history?period=${period}`),
  
  // Dashboard
  getDashboardSummary: () => 
    axios.get(`${API_BASE_URL}/dashboard/summary`),
};
```

### Step 7: Test Setup

```bash
npm run dev
```

Visit `http://localhost:5173` - you should see the Vite default page!

---

## DAY 4-5: BUILD BASIC DASHBOARD (6-8 hours)

### Step 1: Create Layout Component

Create `src/components/Layout.jsx`:
```javascript
export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-900 text-white p-4 shadow-lg">
        <div className="container mx-auto">
          <h1 className="text-2xl font-bold">
            Flood Alert System - Western Province
          </h1>
          <p className="text-sm text-blue-200">
            Real-time monitoring and risk assessment
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-4">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white p-4 mt-8">
        <div className="container mx-auto text-center text-sm">
          <p>© 2025 Flood Alert System | Developed by Thiwanka Lakshan</p>
        </div>
      </footer>
    </div>
  );
}
```

### Step 2: Create Dashboard Page

Create `src/pages/Dashboard.jsx`:
```javascript
import { useState, useEffect } from 'react';
import { api } from '../services/api';

export default function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchDashboardData();
    // Refresh every 5 minutes
    const interval = setInterval(fetchDashboardData, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await api.getDashboardSummary();
      setSummary(response.data.data);
      setError(null);
    } catch (err) {
      setError('Failed to load dashboard data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        {error}
      </div>
    );
  }

  const getRiskColor = (level) => {
    const colors = {
      CRITICAL: 'bg-red-500',
      HIGH: 'bg-orange-500',
      MODERATE: 'bg-yellow-500',
      LOW: 'bg-green-500'
    };
    return colors[level] || 'bg-gray-500';
  };

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500 text-sm font-medium">Total Locations</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">
            {summary.totalLocations}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500 text-sm font-medium">Active Alerts</h3>
          <p className="text-3xl font-bold text-orange-600 mt-2">
            {summary.activeAlerts}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500 text-sm font-medium">Last Update</h3>
          <p className="text-sm font-medium text-gray-900 mt-2">
            {new Date(summary.lastUpdate).toLocaleString()}
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500 text-sm font-medium">System Status</h3>
          <p className="text-lg font-bold text-green-600 mt-2">
            ● Online
          </p>
        </div>
      </div>

      {/* Risk Distribution */}
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Risk Distribution</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(summary.riskDistribution).map(([level, count]) => (
            <div key={level} className="text-center">
              <div className={`${getRiskColor(level)} text-white py-8 rounded-lg`}>
                <div className="text-4xl font-bold">{count}</div>
                <div className="text-sm mt-2">{level}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
```

### Step 3: Update App.jsx

Update `src/App.jsx`:
```javascript
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <Layout>
      <Dashboard />
    </Layout>
  );
}

export default App;
```

### Step 4: Test Dashboard

```bash
# Make sure backend is running on port 5000
# In another terminal:
npm run dev
```

Visit `http://localhost:5173` - you should see your dashboard with real data!

---

## DAY 6-7: POLISH & RESPONSIVE DESIGN (4-6 hours)

### Tasks:
1. **Mobile Responsiveness**
   - Test on different screen sizes (Chrome DevTools)
   - Adjust grid columns for mobile
   - Ensure text is readable on small screens

2. **Loading States**
   - Add spinner component
   - Skeleton loading for cards

3. **Error Handling**
   - Better error messages
   - Retry buttons

4. **Auto-refresh**
   - Already implemented in useEffect
   - Add visual indicator when refreshing

### Example Spinner Component:

Create `src/components/Spinner.jsx`:
```javascript
export default function Spinner() {
  return (
    <div className="flex justify-center items-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900"></div>
    </div>
  );
}
```

---

## ✅ WEEK 3 CHECKLIST

- [ ] React fundamentals learned
- [ ] Frontend project created with Vite
- [ ] Tailwind CSS configured
- [ ] API service created
- [ ] Layout component built
- [ ] Dashboard page showing summary
- [ ] Real data from backend API
- [ ] Mobile responsive
- [ ] Loading and error states
- [ ] Code committed to GitHub

---

# WEEK 4: INTERACTIVE MAP

**Goal:** Leaflet map with color-coded location markers

## DAY 1-2: LEAFLET SETUP (4-6 hours)

### Step 1: Install Dependencies

```bash
npm install leaflet react-leaflet
```

### Step 2: Import Leaflet CSS

Add to `src/App.jsx` or `index.html`:
```html
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
```

### Step 3: Create Map Component

Create `src/components/Map.jsx`:
```javascript
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useEffect, useState } from 'react';
import { api } from '../services/api';

export default function FloodMap() {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLocations();
  }, []);

  const fetchLocations = async () => {
    try {
      const response = await api.getLocations();
      setLocations(response.data.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching locations:', error);
      setLoading(false);
    }
  };

  const getRiskColor = (riskLevel) => {
    const colors = {
      'CRITICAL': '#DC2626',
      'HIGH': '#F97316',
      'MODERATE': '#EAB308',
      'LOW': '#22C55E'
    };
    return colors[riskLevel] || '#22C55E';
  };

  // Center on Western Province
  const center = [6.9271, 79.8612]; // Colombo coordinates
  const zoom = 10;

  if (loading) {
    return <div className="h-96 flex items-center justify-center">Loading map...</div>;
  }

  return (
    <div className="h-[600px] rounded-lg overflow-hidden shadow-lg">
      <MapContainer center={center} zoom={zoom} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        />
        
        {locations.map((location) => (
          <CircleMarker
            key={location.id}
            center={[location.latitude, location.longitude]}
            radius={12}
            fillColor={getRiskColor(location.current_risk_level)}
            color="#fff"
            weight={2}
            opacity={1}
            fillOpacity={0.8}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-bold text-lg">{location.name}</h3>
                <p className="text-sm text-gray-600">{location.district}</p>
                <div className="mt-2">
                  <span className="text-sm font-semibold">Risk Level: </span>
                  <span 
                    className="text-sm font-bold"
                    style={{ color: getRiskColor(location.current_risk_level) }}
                  >
                    {location.current_risk_level || 'UNKNOWN'}
                  </span>
                </div>
                <div className="text-sm text-gray-600">
                  Elevation: {location.elevation}m
                </div>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}
```

### Step 4: Add Map to Dashboard

Update `src/pages/Dashboard.jsx`:
```javascript
import FloodMap from '../components/Map';

// Inside return statement, add:
<div className="bg-white p-6 rounded-lg shadow">
  <h2 className="text-xl font-bold mb-4">Location Risk Map</h2>
  <FloodMap />
</div>
```

---

## DAY 3-4: MAP LEGEND & INTERACTIVITY (4-6 hours)

### Add Map Legend

Create `src/components/MapLegend.jsx`:
```javascript
export default function MapLegend() {
  const items = [
    { level: 'CRITICAL', color: '#DC2626', label: 'Critical Risk' },
    { level: 'HIGH', color: '#F97316', label: 'High Risk' },
    { level: 'MODERATE', color: '#EAB308', label: 'Moderate Risk' },
    { level: 'LOW', color: '#22C55E', label: 'Low Risk' }
  ];

  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="font-bold text-sm mb-2">Risk Levels</h3>
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.level} className="flex items-center space-x-2">
            <div 
              className="w-4 h-4 rounded-full"
              style={{ backgroundColor: item.color }}
            />
            <span className="text-sm">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
```

---

## DAY 5-7: LOCATION DETAIL PAGE (6-8 hours)

### Create Location Detail Page

Create `src/pages/LocationDetail.jsx`:
```javascript
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../services/api';

export default function LocationDetail() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLocationData();
  }, [id]);

  const fetchLocationData = async () => {
    try {
      const response = await api.getLocation(id);
      setData(response.data.data);
      setLoading(false);
    } catch (error) {
      console.error('Error:', error);
      setLoading(false);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!data) return <div>Location not found</div>;

  return (
    <div className="space-y-6">
      <Link to="/" className="text-blue-600 hover:underline">
        ← Back to Dashboard
      </Link>

      <div className="bg-white p-6 rounded-lg shadow">
        <h1 className="text-3xl font-bold">{data.location.name}</h1>
        <p className="text-gray-600">{data.location.district} District</p>
        
        <div className="grid grid-cols-2 gap-4 mt-4">
          <div>
            <span className="text-sm text-gray-500">Elevation</span>
            <p className="font-semibold">{data.location.elevation}m</p>
          </div>
          <div>
            <span className="text-sm text-gray-500">Population</span>
            <p className="font-semibold">{data.location.population?.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Current Risk */}
      {data.currentRisk && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Current Risk Assessment</h2>
          <div className="text-center">
            <div 
              className="inline-block px-6 py-3 rounded-lg text-white font-bold text-2xl"
              style={{ backgroundColor: data.currentRisk.riskColor }}
            >
              {data.currentRisk.risk_level}
            </div>
            <p className="mt-2 text-gray-600">
              {data.currentRisk.recommendedAction}
            </p>
          </div>
        </div>
      )}

      {/* Current Weather */}
      {data.currentWeather && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Current Weather</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <span className="text-sm text-gray-500">Temperature</span>
              <p className="font-semibold">{data.currentWeather.temperature}°C</p>
            </div>
            <div>
              <span className="text-sm text-gray-500">Humidity</span>
              <p className="font-semibold">{data.currentWeather.humidity}%</p>
            </div>
            <div>
              <span className="text-sm text-gray-500">24h Rainfall</span>
              <p className="font-semibold">{data.currentWeather.rainfall_24h}mm</p>
            </div>
            <div>
              <span className="text-sm text-gray-500">72h Rainfall</span>
              <p className="font-semibold">{data.currentWeather.rainfall_72h}mm</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
```

### Set Up Routing

Update `src/App.jsx`:
```javascript
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import LocationDetail from './pages/LocationDetail';

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/location/:id" element={<LocationDetail />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;
```

---

## ✅ WEEK 4 CHECKLIST

- [ ] Leaflet installed and configured
- [ ] Map displaying Western Province
- [ ] Color-coded markers by risk level
- [ ] Clickable markers with popups
- [ ] Map legend
- [ ] Location detail page
- [ ] Routing between pages
- [ ] Mobile responsive map

---

# WEEKS 5-8: CONDENSED GUIDE

Due to length, here's a condensed overview of remaining weeks. Full detailed guides available on request.

## WEEK 5: ALERT SYSTEM

### Key Tasks:
1. **Email Alerts (Nodemailer)**
   - Configure Gmail SMTP
   - Create email templates
   - Implement sendEmail function

2. **SMS Alerts (Twilio)**
   - Sign up for Twilio trial
   - Implement sendSMS function
   - Test with your phone number

3. **Alert Logic**
   - Trigger alerts when risk changes
   - Store alerts in database
   - Prevent duplicate alerts

4. **Subscription Management**
   - Create subscription form
   - API endpoints for subscribe/unsubscribe
   - Test end-to-end flow

---

## WEEK 6: CHARTS & HISTORICAL DATA

### Key Tasks:
1. **Install Chart.js**
   ```bash
   npm install chart.js react-chartjs-2
   ```

2. **Create Rainfall Chart Component**
   - Line chart showing 7-day rainfall
   - 24h and 30d options
   - Responsive design

3. **Risk History Chart**
   - Show risk level over time
   - Color-coded by risk level

4. **Historical Flood Events**
   - Display timeline of past floods
   - Add to location detail pages

---

## WEEK 7: ADMIN PANEL & POLISH

### Key Tasks:
1. **JWT Authentication**
   - Create admin login page
   - Implement JWT middleware
   - Protect admin routes

2. **Admin Dashboard**
   - View all alerts
   - System logs
   - User management

3. **UI Polish**
   - Consistent styling
   - Loading states everywhere
   - Better error messages
   - Smooth transitions

4. **Mobile Testing**
   - Test on real devices
   - Fix responsive issues
   - Optimize performance

---

## WEEK 8: DEPLOYMENT & DOCUMENTATION

### Key Tasks:
1. **Backend Deployment (Railway)**
   - Create Railway account
   - Deploy backend + database
   - Configure environment variables
   - Test production API

2. **Frontend Deployment (Vercel)**
   - Create Vercel account
   - Deploy React app
   - Update API URLs
   - Test production site

3. **Documentation**
   - Complete README
   - User guide
   - API documentation
   - Architecture diagrams

4. **Presentation**
   - Create slides
   - Record demo video
   - Practice presentation
   - Prepare for Q&A

---

## ✅ FINAL PROJECT CHECKLIST

**Backend:**
- [ ] Weather data collecting automatically
- [ ] Risk calculation working
- [ ] All API endpoints functional
- [ ] Deployed to Railway
- [ ] Database backed up

**Frontend:**
- [ ] Dashboard with summary
- [ ] Interactive map
- [ ] Location detail pages
- [ ] Charts displaying data
- [ ] Mobile responsive
- [ ] Deployed to Vercel

**Features:**
- [ ] Email alerts working
- [ ] SMS alerts working (or just email)
- [ ] Admin panel functional
- [ ] Error handling throughout

**Documentation:**
- [ ] README complete
- [ ] API docs written
- [ ] User guide created
- [ ] Code commented

**Presentation:**
- [ ] Demo video recorded
- [ ] Slides prepared
- [ ] Practice run completed
- [ ] Backup plan ready

---

## YOU GOT THIS! 🚀

Remember: Done is better than perfect. Focus on getting core features working before adding extras. You have detailed Week 1 and Week 2 guides to get started - follow them carefully!

**START TODAY. BUILD SOMETHING AMAZING. HELP YOUR COMMUNITY.** 💪
