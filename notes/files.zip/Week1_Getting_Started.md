# WEEK 1: GETTING STARTED - EXACT STEPS

**Start Date:** Today!  
**End Date:** 7 days from now  
**Goal:** Backend running, database set up, weather data collecting

---

## DAY 1: PROJECT SETUP (2-3 hours)

### Step 1: Install Required Software (if not already installed)

```bash
# Check if Node.js is installed (need v18 or higher)
node --version

# Check if PostgreSQL is installed
psql --version

# If not installed:
# - Node.js: Download from https://nodejs.org/
# - PostgreSQL: Download from https://www.postgresql.org/download/
```

### Step 2: Create Project Directory

```bash
# Create project folder
mkdir flood-alert-system
cd flood-alert-system

# Create backend folder
mkdir backend
cd backend

# Initialize Node.js project
npm init -y
```

### Step 3: Install Dependencies

```bash
# Core dependencies
npm install express pg cors dotenv axios node-cron

# Development dependencies
npm install --save-dev nodemon

# Optional but recommended
npm install express-validator
```

### Step 4: Create Project Structure

```bash
# Create folders
mkdir config routes controllers services models utils

# Create files
touch server.js
touch .env
touch .gitignore
```

### Step 5: Set Up `.gitignore`

Create `.gitignore` file:
```
node_modules/
.env
*.log
.DS_Store
```

### Step 6: Set Up Environment Variables

Create `.env` file:
```
PORT=5000
NODE_ENV=development

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=flood_alert_db
DB_USER=postgres
DB_PASSWORD=your_password_here

# OpenWeatherMap API (get this in Day 3)
OPENWEATHER_API_KEY=your_api_key_here

# Later (Week 5)
GMAIL_USER=
GMAIL_PASSWORD=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_PHONE_NUMBER=
```

### Step 7: Create Basic Server

Create `server.js`:
```javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Test route
app.get('/', (req, res) => {
  res.json({ message: 'Flood Alert System API - Running!' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

### Step 8: Update `package.json` Scripts

Add to `package.json`:
```json
"scripts": {
  "start": "node server.js",
  "dev": "nodemon server.js",
  "test": "echo \"No tests yet\""
}
```

### Step 9: Test Server

```bash
npm run dev

# Open browser: http://localhost:5000
# You should see: {"message": "Flood Alert System API - Running!"}
```

### Step 10: Initialize Git

```bash
git init
git add .
git commit -m "Initial project setup"

# Create GitHub repo and push
git remote add origin YOUR_GITHUB_REPO_URL
git push -u origin main
```

**✅ Day 1 Complete! Server is running!**

---

## DAY 2: DATABASE SETUP (3-4 hours)

### Step 1: Create Database

```bash
# Open PostgreSQL
psql -U postgres

# In psql:
CREATE DATABASE flood_alert_db;

# Connect to database
\c flood_alert_db

# Enable PostGIS extension
CREATE EXTENSION postgis;

# Verify PostGIS
SELECT PostGIS_version();

# Exit psql
\q
```

### Step 2: Create Database Config

Create `config/database.js`:
```javascript
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

pool.on('connect', () => {
  console.log('✅ Database connected successfully');
});

pool.on('error', (err) => {
  console.error('❌ Database connection error:', err);
});

module.exports = pool;
```

### Step 3: Create Database Schema Script

Create `config/schema.sql`:
```sql
-- Locations table
CREATE TABLE locations (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  district VARCHAR(100) NOT NULL,
  gn_division VARCHAR(255),
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  elevation INTEGER,
  population INTEGER,
  geom GEOMETRY(Point, 4326),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create spatial index
CREATE INDEX idx_locations_geom ON locations USING GIST(geom);

-- Weather data table
CREATE TABLE weather_data (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  timestamp TIMESTAMP NOT NULL,
  temperature DECIMAL(5, 2),
  humidity INTEGER,
  rainfall_1h DECIMAL(6, 2),
  rainfall_24h DECIMAL(6, 2),
  rainfall_72h DECIMAL(6, 2),
  wind_speed DECIMAL(5, 2),
  pressure INTEGER,
  weather_condition VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_weather_location_time ON weather_data(location_id, timestamp DESC);

-- Risk assessments table
CREATE TABLE risk_assessments (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  timestamp TIMESTAMP NOT NULL,
  risk_level VARCHAR(20) NOT NULL,
  risk_score INTEGER NOT NULL,
  factors JSONB,
  rainfall_24h DECIMAL(6, 2),
  rainfall_72h DECIMAL(6, 2),
  elevation_factor INTEGER,
  season_factor INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_risk_location_time ON risk_assessments(location_id, timestamp DESC);

-- Alerts table
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  risk_assessment_id INTEGER REFERENCES risk_assessments(id),
  alert_type VARCHAR(20) NOT NULL,
  recipient VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL,
  sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_alerts_status ON alerts(status, created_at);

-- Alert subscriptions table
CREATE TABLE alert_subscriptions (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  phone_number VARCHAR(20),
  email VARCHAR(255),
  is_active BOOLEAN DEFAULT true,
  min_risk_level VARCHAR(20) DEFAULT 'MODERATE',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Historical floods table
CREATE TABLE historical_floods (
  id SERIAL PRIMARY KEY,
  location_id INTEGER REFERENCES locations(id),
  flood_date DATE NOT NULL,
  severity VARCHAR(20),
  casualties INTEGER DEFAULT 0,
  affected_population INTEGER,
  damage_estimate DECIMAL(12, 2),
  description TEXT,
  source VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System logs table
CREATE TABLE system_logs (
  id SERIAL PRIMARY KEY,
  log_type VARCHAR(50) NOT NULL,
  message TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_logs_type_time ON system_logs(log_type, created_at DESC);
```

### Step 4: Run Schema Script

```bash
# From your project directory
psql -U postgres -d flood_alert_db -f config/schema.sql
```

### Step 5: Create Seed Data Script

Create `config/seed.sql`:
```sql
-- Seed locations (Western Province high-risk areas)
INSERT INTO locations (name, district, gn_division, latitude, longitude, elevation, population, geom) VALUES
('Wellampitiya', 'Colombo', 'Kolonnawa', 6.9497, 79.9258, 3, 45000, ST_SetSRID(ST_MakePoint(79.9258, 6.9497), 4326)),
('Kelanimulla', 'Colombo', 'Kolonnawa', 6.9525, 79.9311, 4, 38000, ST_SetSRID(ST_MakePoint(79.9311, 6.9525), 4326)),
('Gotatuwa', 'Colombo', 'Kolonnawa', 6.9563, 79.9342, 5, 32000, ST_SetSRID(ST_MakePoint(79.9342, 6.9563), 4326)),
('Malabe', 'Colombo', 'Kaduwela', 6.9094, 79.9528, 8, 55000, ST_SetSRID(ST_MakePoint(79.9528, 6.9094), 4326)),
('Angoda', 'Colombo', 'Kaduwela', 6.9228, 79.9275, 6, 42000, ST_SetSRID(ST_MakePoint(79.9275, 6.9228), 4326)),
('Kottikawatte', 'Colombo', 'Borella', 6.9172, 79.8747, 5, 28000, ST_SetSRID(ST_MakePoint(79.8747, 6.9172), 4326)),
('Mattakkuliya', 'Colombo', 'Colombo North', 6.9656, 79.8603, 2, 35000, ST_SetSRID(ST_MakePoint(79.8603, 6.9656), 4326)),
('Grandpass', 'Colombo', 'Colombo North', 6.9447, 79.8564, 3, 40000, ST_SetSRID(ST_MakePoint(79.8564, 6.9447), 4326)),
('Gampaha', 'Gampaha', 'Gampaha', 7.0914, 80.0140, 12, 75000, ST_SetSRID(ST_MakePoint(80.0140, 7.0914), 4326)),
('Biyagama', 'Gampaha', 'Biyagama', 6.9636, 80.0089, 10, 48000, ST_SetSRID(ST_MakePoint(80.0089, 6.9636), 4326)),
('Wattala', 'Gampaha', 'Wattala', 6.9889, 79.8917, 4, 62000, ST_SetSRID(ST_MakePoint(79.8917, 6.9889), 4326)),
('Kelaniya', 'Gampaha', 'Kelaniya', 6.9553, 79.9200, 7, 58000, ST_SetSRID(ST_MakePoint(79.9200, 6.9553), 4326)),
('Kalutara', 'Kalutara', 'Kalutara', 6.5833, 79.9611, 5, 42000, ST_SetSRID(ST_MakePoint(79.9611, 6.5833), 4326)),
('Panadura', 'Kalutara', 'Panadura', 6.7133, 79.9025, 3, 38000, ST_SetSRID(ST_MakePoint(79.9025, 6.7133), 4326)),
('Wadduwa', 'Kalutara', 'Wadduwa', 6.6669, 79.9281, 2, 25000, ST_SetSRID(ST_MakePoint(79.9281, 6.6669), 4326));

-- Seed historical floods (major events)
INSERT INTO historical_floods (location_id, flood_date, severity, casualties, affected_population, description, source) VALUES
(1, '2016-05-17', 'SEVERE', 4, 172000, 'Heavy monsoon rains caused widespread flooding in Colombo and surrounding areas. Kelani River overflowed.', 'ReliefWeb'),
(2, '2016-05-17', 'SEVERE', 3, 122000, 'Gampaha district severely affected by monsoon floods.', 'ReliefWeb'),
(1, '2017-05-26', 'CATASTROPHIC', 8, 185000, 'Kelani River reached 15.44m water level, causing catastrophic flooding.', 'Wikipedia - 2017 Sri Lanka Floods'),
(9, '2018-05-23', 'MODERATE', 0, 45000, 'Moderate flooding in Gampaha town due to heavy rainfall.', 'Disaster Management Centre'),
(1, '2024-06-03', 'SEVERE', 2, 159000, 'Southwest monsoon intensified, causing severe flooding across Western Province.', 'ReliefWeb'),
(12, '2024-06-03', 'SEVERE', 3, 78000, 'Kelaniya area heavily flooded, schools closed.', 'Save the Children');
```

### Step 6: Run Seed Script

```bash
psql -U postgres -d flood_alert_db -f config/seed.sql
```

### Step 7: Test Database Connection

Create `test-db.js`:
```javascript
const pool = require('./config/database');

async function testDatabase() {
  try {
    // Test connection
    const result = await pool.query('SELECT NOW()');
    console.log('✅ Database connection successful!');
    console.log('Current time from DB:', result.rows[0].now);
    
    // Test locations query
    const locations = await pool.query('SELECT COUNT(*) FROM locations');
    console.log('✅ Locations count:', locations.rows[0].count);
    
    process.exit(0);
  } catch (err) {
    console.error('❌ Database test failed:', err);
    process.exit(1);
  }
}

testDatabase();
```

Run test:
```bash
node test-db.js
```

**✅ Day 2 Complete! Database is set up with 15 locations!**

---

## DAY 3: OPENWEATHERMAP API INTEGRATION (2-3 hours)

### Step 1: Sign Up for OpenWeatherMap

1. Go to https://openweathermap.org/api
2. Click "Sign Up" (free tier is perfect)
3. Verify your email
4. Go to API Keys section
5. Copy your API key
6. Add to `.env` file: `OPENWEATHER_API_KEY=your_actual_key_here`

### Step 2: Create Weather Service

Create `services/weatherService.js`:
```javascript
const axios = require('axios');
const pool = require('../config/database');

const API_KEY = process.env.OPENWEATHER_API_KEY;
const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

class WeatherService {
  async fetchWeatherForLocation(latitude, longitude, locationId) {
    try {
      const response = await axios.get(BASE_URL, {
        params: {
          lat: latitude,
          lon: longitude,
          appid: API_KEY,
          units: 'metric' // Celsius
        }
      });

      const data = response.data;
      
      // Extract relevant data
      const weatherData = {
        locationId,
        timestamp: new Date(),
        temperature: data.main.temp,
        humidity: data.main.humidity,
        rainfall_1h: data.rain ? data.rain['1h'] || 0 : 0,
        windSpeed: data.wind.speed,
        pressure: data.main.pressure,
        weatherCondition: data.weather[0].description
      };

      // Save to database
      await this.saveWeatherData(weatherData);
      
      console.log(`✅ Weather data fetched for location ${locationId}`);
      return weatherData;
      
    } catch (error) {
      console.error(`❌ Error fetching weather for location ${locationId}:`, error.message);
      throw error;
    }
  }

  async saveWeatherData(data) {
    const query = `
      INSERT INTO weather_data 
      (location_id, timestamp, temperature, humidity, rainfall_1h, wind_speed, pressure, weather_condition)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id
    `;
    
    const values = [
      data.locationId,
      data.timestamp,
      data.temperature,
      data.humidity,
      data.rainfall_1h,
      data.windSpeed,
      data.pressure,
      data.weatherCondition
    ];
    
    try {
      const result = await pool.query(query, values);
      return result.rows[0].id;
    } catch (error) {
      console.error('❌ Error saving weather data:', error);
      throw error;
    }
  }

  async fetchWeatherForAllLocations() {
    try {
      // Get all locations
      const locationsResult = await pool.query('SELECT id, latitude, longitude, name FROM locations');
      const locations = locationsResult.rows;
      
      console.log(`📡 Fetching weather for ${locations.length} locations...`);
      
      // Fetch weather for each location
      const promises = locations.map(loc => 
        this.fetchWeatherForLocation(loc.latitude, loc.longitude, loc.id)
      );
      
      await Promise.all(promises);
      
      console.log('✅ Weather data fetched for all locations');
      
    } catch (error) {
      console.error('❌ Error fetching weather for all locations:', error);
      throw error;
    }
  }
}

module.exports = new WeatherService();
```

### Step 3: Test Weather API

Create `test-weather.js`:
```javascript
const weatherService = require('./services/weatherService');

async function testWeather() {
  try {
    console.log('Testing weather API...');
    await weatherService.fetchWeatherForAllLocations();
    console.log('✅ Weather API test successful!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Weather API test failed:', err);
    process.exit(1);
  }
}

testWeather();
```

Run test:
```bash
node test-weather.js
```

### Step 4: Check Database

```bash
psql -U postgres -d flood_alert_db

# In psql:
SELECT location_id, temperature, humidity, rainfall_1h, timestamp 
FROM weather_data 
ORDER BY timestamp DESC 
LIMIT 10;
```

You should see weather data for all locations!

**✅ Day 3 Complete! Weather API working!**

---

## DAY 4-5: AUTOMATED DATA COLLECTION (3-4 hours)

### Step 1: Create Scheduled Job

Create `services/scheduler.js`:
```javascript
const cron = require('node-cron');
const weatherService = require('./weatherService');
const pool = require('../config/database');

class Scheduler {
  start() {
    console.log('🕐 Starting scheduled jobs...');
    
    // Fetch weather every 30 minutes
    // Cron format: minute hour day month day-of-week
    // '*/30 * * * *' = every 30 minutes
    cron.schedule('*/30 * * * *', async () => {
      console.log('⏰ Running scheduled weather collection...');
      
      try {
        await weatherService.fetchWeatherForAllLocations();
        
        // Update 24h and 72h rainfall aggregates
        await this.updateRainfallAggregates();
        
        console.log('✅ Scheduled weather collection completed');
        
      } catch (error) {
        console.error('❌ Scheduled job error:', error);
        
        // Log error to database
        await this.logError(error);
      }
    });
    
    console.log('✅ Scheduler started - weather will be collected every 30 minutes');
  }

  async updateRainfallAggregates() {
    console.log('📊 Updating rainfall aggregates...');
    
    try {
      // Get all locations
      const locationsResult = await pool.query('SELECT id FROM locations');
      const locations = locationsResult.rows;
      
      for (const location of locations) {
        // Calculate 24h rainfall
        const rainfall24h = await pool.query(`
          SELECT COALESCE(SUM(rainfall_1h), 0) as total
          FROM weather_data
          WHERE location_id = $1
          AND timestamp >= NOW() - INTERVAL '24 hours'
        `, [location.id]);
        
        // Calculate 72h rainfall
        const rainfall72h = await pool.query(`
          SELECT COALESCE(SUM(rainfall_1h), 0) as total
          FROM weather_data
          WHERE location_id = $1
          AND timestamp >= NOW() - INTERVAL '72 hours'
        `, [location.id]);
        
        // Update latest weather record
        await pool.query(`
          UPDATE weather_data
          SET rainfall_24h = $1, rainfall_72h = $2
          WHERE location_id = $3
          AND id = (
            SELECT id FROM weather_data
            WHERE location_id = $3
            ORDER BY timestamp DESC
            LIMIT 1
          )
        `, [
          rainfall24h.rows[0].total,
          rainfall72h.rows[0].total,
          location.id
        ]);
      }
      
      console.log('✅ Rainfall aggregates updated');
      
    } catch (error) {
      console.error('❌ Error updating aggregates:', error);
      throw error;
    }
  }

  async logError(error) {
    const query = `
      INSERT INTO system_logs (log_type, message, metadata)
      VALUES ($1, $2, $3)
    `;
    
    const values = [
      'ERROR',
      error.message,
      JSON.stringify({ stack: error.stack, timestamp: new Date() })
    ];
    
    try {
      await pool.query(query, values);
    } catch (err) {
      console.error('Failed to log error:', err);
    }
  }
}

module.exports = new Scheduler();
```

### Step 2: Update server.js to Start Scheduler

Update `server.js`:
```javascript
const express = require('express');
const cors = require('cors');
const scheduler = require('./services/scheduler');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Test route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Flood Alert System API',
    status: 'running',
    timestamp: new Date()
  });
});

// Health check route
app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// Start scheduler
scheduler.start();

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 Weather data collection active`);
});
```

### Step 3: Run Server with Scheduler

```bash
npm run dev
```

You should see:
```
🚀 Server running on port 5000
📡 Weather data collection active
🕐 Starting scheduled jobs...
✅ Scheduler started - weather will be collected every 30 minutes
```

### Step 4: Monitor Data Collection

Watch your database fill up:
```bash
# Open another terminal
psql -U postgres -d flood_alert_db

# Check weather data count
SELECT COUNT(*) FROM weather_data;

# Wait 30 minutes, check again - should increase!
```

**✅ Days 4-5 Complete! Automated collection running!**

---

## DAY 6-7: CLEANUP & TESTING (2-3 hours)

### Day 6: Error Handling & Logging

Add proper error handling to all services (I'll spare you the full code, but make sure every function has try-catch!)

### Day 7: Documentation & Git

Create `README.md`:
```markdown
# Flood Alert & Monitoring System - Backend

Real-time flood monitoring and risk assessment system for Western Province, Sri Lanka.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Set up PostgreSQL database and run schema:
```bash
psql -U postgres -f config/schema.sql
psql -U postgres -f config/seed.sql
```

3. Configure environment variables in `.env`

4. Run development server:
```bash
npm run dev
```

## Features

- ✅ Real-time weather data collection (every 30 mins)
- ✅ 15 high-risk locations monitored
- ✅ Automated rainfall aggregation (24h, 72h)
- ✅ PostgreSQL with PostGIS for geospatial data
- 🚧 Risk calculation (Week 2)
- 🚧 REST API endpoints (Week 2)
- 🚧 Alert system (Week 5)

## Tech Stack

- Node.js + Express
- PostgreSQL + PostGIS
- OpenWeatherMap API
- node-cron
```

Commit and push:
```bash
git add .
git commit -m "Week 1 complete: Weather data collection automated"
git push
```

---

## ✅ WEEK 1 CHECKLIST

- [ ] Node.js project initialized
- [ ] PostgreSQL database created with PostGIS
- [ ] All 7 tables created
- [ ] 15 locations seeded
- [ ] OpenWeatherMap API integrated
- [ ] Weather data being collected automatically every 30 mins
- [ ] Rainfall aggregates (24h, 72h) calculated
- [ ] Error logging to database
- [ ] Code committed to GitHub
- [ ] README.md written

**If you checked all boxes, YOU'RE AHEAD OF SCHEDULE! 🎉**

---

## NEXT STEPS (Week 2 Preview)

Next week you'll build:
- Risk calculation algorithm
- REST API endpoints
- Location, weather, and risk routes
- Postman testing

But for now, CELEBRATE! Week 1 done! 🎊

---

Need help? Common issues and solutions are in the main project plan document.

**LET'S GO THIWANKA! 🚀**
