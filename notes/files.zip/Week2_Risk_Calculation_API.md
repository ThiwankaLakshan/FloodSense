# WEEK 2: RISK CALCULATION & REST API - EXACT STEPS

**Start Date:** Week 2, Day 1  
**End Date:** Week 2, Day 7  
**Goal:** Risk calculation working, complete REST API, all endpoints tested

---

## OVERVIEW

This week you're building the BRAIN of your system:
- Risk calculation service (the algorithm)
- REST API endpoints for frontend
- Testing with Postman
- API documentation

By end of week: Your backend will calculate flood risk and serve it via API!

---

## DAY 1: RISK CALCULATOR FOUNDATION (3-4 hours)

### Step 1: Create Risk Rules Configuration

Create `config/riskRules.js`:
```javascript
module.exports = {
  // Rainfall scoring rules
  rainfall: {
    rainfall24h: [
      { min: 200, score: 4, label: 'Extreme 24h rainfall' },
      { min: 150, score: 3, label: 'Very heavy 24h rainfall' },
      { min: 100, score: 2, label: 'Heavy 24h rainfall' },
      { min: 50, score: 1, label: 'Moderate 24h rainfall' }
    ],
    rainfall72h: [
      { min: 400, score: 4, label: 'Extreme 72h rainfall' },
      { min: 300, score: 3, label: 'Very heavy 72h rainfall' },
      { min: 200, score: 2, label: 'Heavy 72h rainfall' },
      { min: 100, score: 1, label: 'Moderate 72h rainfall' }
    ]
  },
  
  // Elevation scoring
  elevation: [
    { max: 5, score: 3, label: 'Extremely low elevation' },
    { max: 10, score: 2, label: 'Very low elevation' },
    { max: 25, score: 1, label: 'Low elevation' }
  ],
  
  // Season scoring
  season: [
    { months: [5, 6, 7, 8, 9], score: 2, label: 'SW Monsoon season' },
    { months: [10, 11, 12, 1], score: 2, label: 'NE Monsoon season' },
    { months: [3, 4], score: 1, label: 'Inter-monsoon period' }
  ],
  
  // Historical flood frequency
  historicalFlood: [
    { floodsLast5Years: 3, score: 2, label: 'Frequently flooded area' },
    { floodsLast5Years: 1, score: 1, label: 'Previously flooded area' }
  ],
  
  // Risk level mapping
  riskLevels: [
    { 
      minScore: 9, 
      level: 'CRITICAL', 
      color: '#DC2626', 
      action: 'Evacuate immediately to higher ground' 
    },
    { 
      minScore: 6, 
      level: 'HIGH', 
      color: '#F97316', 
      action: 'Prepare to evacuate - secure property and gather emergency supplies' 
    },
    { 
      minScore: 3, 
      level: 'MODERATE', 
      color: '#EAB308', 
      action: 'Stay alert - monitor updates and review evacuation plan' 
    },
    { 
      minScore: 0, 
      level: 'LOW', 
      color: '#22C55E', 
      action: 'Normal conditions - maintain general awareness' 
    }
  ]
};
```

### Step 2: Create Risk Calculator Service

Create `services/riskCalculator.js`:
```javascript
const riskRules = require('../config/riskRules');
const pool = require('../config/database');

class RiskCalculator {
  /**
   * Calculate risk for a location
   */
  async calculateRisk(locationId) {
    try {
      // Get location details
      const locationResult = await pool.query(
        'SELECT * FROM locations WHERE id = $1',
        [locationId]
      );
      
      if (locationResult.rows.length === 0) {
        throw new Error(`Location ${locationId} not found`);
      }
      
      const location = locationResult.rows[0];
      
      // Get latest weather data
      const weatherResult = await pool.query(
        `SELECT * FROM weather_data 
         WHERE location_id = $1 
         ORDER BY timestamp DESC 
         LIMIT 1`,
        [locationId]
      );
      
      if (weatherResult.rows.length === 0) {
        return null; // No weather data yet
      }
      
      const weather = weatherResult.rows[0];
      
      // Get historical floods for this location
      const floodsResult = await pool.query(
        `SELECT * FROM historical_floods 
         WHERE location_id = $1 
         AND flood_date >= CURRENT_DATE - INTERVAL '5 years'`,
        [locationId]
      );
      
      const historicalFloods = floodsResult.rows;
      
      // Calculate risk score
      const riskAssessment = this.computeRiskScore(location, weather, historicalFloods);
      
      // Save to database
      await this.saveRiskAssessment(locationId, riskAssessment, weather);
      
      return riskAssessment;
      
    } catch (error) {
      console.error(`Error calculating risk for location ${locationId}:`, error);
      throw error;
    }
  }
  
  /**
   * Compute risk score based on all factors
   */
  computeRiskScore(location, weather, historicalFloods) {
    let totalScore = 0;
    const factors = [];
    
    // Factor 1: 24-hour rainfall
    const rainfall24hScore = this.scoreRainfall(
      weather.rainfall_24h,
      riskRules.rainfall.rainfall24h
    );
    if (rainfall24hScore.score > 0) {
      totalScore += rainfall24hScore.score;
      factors.push({ ...rainfall24hScore, factor: 'rainfall_24h' });
    }
    
    // Factor 2: 72-hour rainfall
    const rainfall72hScore = this.scoreRainfall(
      weather.rainfall_72h,
      riskRules.rainfall.rainfall72h
    );
    if (rainfall72hScore.score > 0) {
      totalScore += rainfall72hScore.score;
      factors.push({ ...rainfall72hScore, factor: 'rainfall_72h' });
    }
    
    // Factor 3: Elevation
    const elevationScore = this.scoreElevation(location.elevation);
    if (elevationScore.score > 0) {
      totalScore += elevationScore.score;
      factors.push({ ...elevationScore, factor: 'elevation' });
    }
    
    // Factor 4: Season
    const seasonScore = this.scoreSeason();
    if (seasonScore.score > 0) {
      totalScore += seasonScore.score;
      factors.push({ ...seasonScore, factor: 'season' });
    }
    
    // Factor 5: Historical floods
    const historicalScore = this.scoreHistoricalFloods(historicalFloods);
    if (historicalScore.score > 0) {
      totalScore += historicalScore.score;
      factors.push({ ...historicalScore, factor: 'historical' });
    }
    
    // Determine risk level
    const riskLevel = this.getRiskLevel(totalScore);
    
    return {
      riskScore: totalScore,
      riskLevel: riskLevel.level,
      riskColor: riskLevel.color,
      recommendedAction: riskLevel.action,
      factors: factors,
      timestamp: new Date()
    };
  }
  
  /**
   * Score rainfall amount
   */
  scoreRainfall(rainfall, rules) {
    if (!rainfall) return { score: 0 };
    
    for (const rule of rules) {
      if (rainfall >= rule.min) {
        return {
          score: rule.score,
          value: rainfall,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  /**
   * Score elevation
   */
  scoreElevation(elevation) {
    if (!elevation) return { score: 0 };
    
    for (const rule of riskRules.elevation) {
      if (elevation <= rule.max) {
        return {
          score: rule.score,
          value: elevation,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  /**
   * Score current season
   */
  scoreSeason() {
    const currentMonth = new Date().getMonth() + 1; // 1-12
    
    for (const rule of riskRules.season) {
      if (rule.months.includes(currentMonth)) {
        return {
          score: rule.score,
          label: rule.label,
          month: currentMonth
        };
      }
    }
    return { score: 0 };
  }
  
  /**
   * Score historical flood frequency
   */
  scoreHistoricalFloods(floods) {
    const floodCount = floods.length;
    
    for (const rule of riskRules.historicalFlood) {
      if (floodCount >= rule.floodsLast5Years) {
        return {
          score: rule.score,
          value: floodCount,
          label: rule.label
        };
      }
    }
    return { score: 0 };
  }
  
  /**
   * Get risk level from score
   */
  getRiskLevel(score) {
    for (const level of riskRules.riskLevels) {
      if (score >= level.minScore) {
        return level;
      }
    }
    return riskRules.riskLevels[riskRules.riskLevels.length - 1];
  }
  
  /**
   * Save risk assessment to database
   */
  async saveRiskAssessment(locationId, assessment, weather) {
    const query = `
      INSERT INTO risk_assessments 
      (location_id, timestamp, risk_level, risk_score, factors, 
       rainfall_24h, rainfall_72h)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id
    `;
    
    const values = [
      locationId,
      assessment.timestamp,
      assessment.riskLevel,
      assessment.riskScore,
      JSON.stringify(assessment.factors),
      weather.rainfall_24h,
      weather.rainfall_72h
    ];
    
    const result = await pool.query(query, values);
    return result.rows[0].id;
  }
  
  /**
   * Calculate risk for all locations
   */
  async calculateRiskForAllLocations() {
    try {
      const locationsResult = await pool.query('SELECT id FROM locations');
      const locations = locationsResult.rows;
      
      console.log(`🧮 Calculating risk for ${locations.length} locations...`);
      
      for (const location of locations) {
        try {
          const risk = await this.calculateRisk(location.id);
          if (risk) {
            console.log(`✅ Location ${location.id}: ${risk.riskLevel} (score: ${risk.riskScore})`);
          }
        } catch (error) {
          console.error(`❌ Error calculating risk for location ${location.id}:`, error.message);
        }
      }
      
      console.log('✅ Risk calculation complete');
      
    } catch (error) {
      console.error('❌ Error in calculateRiskForAllLocations:', error);
      throw error;
    }
  }
}

module.exports = new RiskCalculator();
```

### Step 3: Test Risk Calculator

Create `test-risk.js`:
```javascript
const riskCalculator = require('./services/riskCalculator');

async function testRiskCalculator() {
  try {
    console.log('Testing risk calculator...\n');
    
    // Calculate for location 1 (Wellampitiya - low elevation)
    console.log('Testing Location 1 (Wellampitiya):');
    const risk1 = await riskCalculator.calculateRisk(1);
    
    if (risk1) {
      console.log(`Risk Level: ${risk1.riskLevel}`);
      console.log(`Risk Score: ${risk1.riskScore}`);
      console.log(`Action: ${risk1.recommendedAction}`);
      console.log('Factors:', risk1.factors);
    }
    
    console.log('\n✅ Risk calculator test successful!');
    process.exit(0);
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

testRiskCalculator();
```

Run test:
```bash
node test-risk.js
```

**✅ Day 1 Complete! Risk calculator working!**

---

## DAY 2: INTEGRATE RISK CALCULATION WITH SCHEDULER (2-3 hours)

### Step 1: Update Scheduler to Calculate Risk

Update `services/scheduler.js`:
```javascript
const cron = require('node-cron');
const weatherService = require('./weatherService');
const riskCalculator = require('./riskCalculator');
const pool = require('../config/database');

class Scheduler {
  start() {
    console.log('🕐 Starting scheduled jobs...');
    
    // Fetch weather and calculate risk every 30 minutes
    cron.schedule('*/30 * * * *', async () => {
      console.log('⏰ Running scheduled tasks...');
      
      try {
        // 1. Fetch weather for all locations
        await weatherService.fetchWeatherForAllLocations();
        
        // 2. Update rainfall aggregates
        await this.updateRainfallAggregates();
        
        // 3. Calculate risk for all locations
        await riskCalculator.calculateRiskForAllLocations();
        
        console.log('✅ Scheduled tasks completed');
        
      } catch (error) {
        console.error('❌ Scheduled job error:', error);
        await this.logError(error);
      }
    });
    
    console.log('✅ Scheduler started');
    console.log('📡 Weather collection: every 30 minutes');
    console.log('🧮 Risk calculation: every 30 minutes');
  }

  async updateRainfallAggregates() {
    console.log('📊 Updating rainfall aggregates...');
    
    try {
      const locationsResult = await pool.query('SELECT id FROM locations');
      const locations = locationsResult.rows;
      
      for (const location of locations) {
        // Calculate 24h rainfall
        const rainfall24h = await pool.query(`
          SELECT COALESCE(SUM(rainfall_1h), 0) as total
          FROM weather_data
          WHERE location_id = $1
          AND timestamp >= NOW() - INTERVAL '24 hours'
        `, [location.id]);
        
        // Calculate 72h rainfall
        const rainfall72h = await pool.query(`
          SELECT COALESCE(SUM(rainfall_1h), 0) as total
          FROM weather_data
          WHERE location_id = $1
          AND timestamp >= NOW() - INTERVAL '72 hours'
        `, [location.id]);
        
        // Update latest weather record
        await pool.query(`
          UPDATE weather_data
          SET rainfall_24h = $1, rainfall_72h = $2
          WHERE location_id = $3
          AND id = (
            SELECT id FROM weather_data
            WHERE location_id = $3
            ORDER BY timestamp DESC
            LIMIT 1
          )
        `, [
          rainfall24h.rows[0].total,
          rainfall72h.rows[0].total,
          location.id
        ]);
      }
      
      console.log('✅ Rainfall aggregates updated');
      
    } catch (error) {
      console.error('❌ Error updating aggregates:', error);
      throw error;
    }
  }

  async logError(error) {
    const query = `
      INSERT INTO system_logs (log_type, message, metadata)
      VALUES ($1, $2, $3)
    `;
    
    const values = [
      'ERROR',
      error.message,
      JSON.stringify({ stack: error.stack, timestamp: new Date() })
    ];
    
    try {
      await pool.query(query, values);
    } catch (err) {
      console.error('Failed to log error:', err);
    }
  }
}

module.exports = new Scheduler();
```

### Step 2: Test Full Pipeline

Restart your server:
```bash
npm run dev
```

Watch the logs - you should see:
```
✅ Scheduler started
📡 Weather collection: every 30 minutes
🧮 Risk calculation: every 30 minutes
```

Check database:
```bash
psql -U postgres -d flood_alert_db

SELECT l.name, r.risk_level, r.risk_score, r.timestamp
FROM risk_assessments r
JOIN locations l ON l.id = r.location_id
ORDER BY r.timestamp DESC
LIMIT 10;
```

**✅ Day 2 Complete! Automated risk calculation working!**

---

## DAY 3-4: BUILD REST API ENDPOINTS (4-6 hours)

### Day 3: Locations API

Create `routes/locations.js`:
```javascript
const express = require('express');
const router = express.Router();
const pool = require('../config/database');

/**
 * GET /api/locations
 * Get all locations with current risk
 */
router.get('/', async (req, res) => {
  try {
    const query = `
      SELECT 
        l.*,
        r.risk_level,
        r.risk_score,
        r.risk_color,
        r.timestamp as risk_timestamp
      FROM locations l
      LEFT JOIN LATERAL (
        SELECT risk_level, risk_score, 
               (factors::json->0->>'color') as risk_color,
               timestamp
        FROM risk_assessments
        WHERE location_id = l.id
        ORDER BY timestamp DESC
        LIMIT 1
      ) r ON true
      ORDER BY l.district, l.name
    `;
    
    const result = await pool.query(query);
    
    res.json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
    
  } catch (error) {
    console.error('Error fetching locations:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch locations'
    });
  }
});

/**
 * GET /api/locations/:id
 * Get single location with detailed info
 */
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get location
    const locationResult = await pool.query(
      'SELECT * FROM locations WHERE id = $1',
      [id]
    );
    
    if (locationResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Location not found'
      });
    }
    
    const location = locationResult.rows[0];
    
    // Get latest weather
    const weatherResult = await pool.query(
      `SELECT * FROM weather_data 
       WHERE location_id = $1 
       ORDER BY timestamp DESC 
       LIMIT 1`,
      [id]
    );
    
    // Get latest risk
    const riskResult = await pool.query(
      `SELECT * FROM risk_assessments 
       WHERE location_id = $1 
       ORDER BY timestamp DESC 
       LIMIT 1`,
      [id]
    );
    
    res.json({
      success: true,
      data: {
        location,
        currentWeather: weatherResult.rows[0] || null,
        currentRisk: riskResult.rows[0] || null
      }
    });
    
  } catch (error) {
    console.error('Error fetching location:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch location'
    });
  }
});

module.exports = router;
```

Create `routes/weather.js`:
```javascript
const express = require('express');
const router = express.Router();
const pool = require('../config/database');

/**
 * GET /api/locations/:id/weather-history
 * Get weather history for charts
 */
router.get('/:id/weather-history', async (req, res) => {
  try {
    const { id } = req.params;
    const { period = '7d' } = req.query;
    
    // Map period to interval
    const intervalMap = {
      '24h': '24 hours',
      '7d': '7 days',
      '30d': '30 days'
    };
    
    const interval = intervalMap[period] || '7 days';
    
    const query = `
      SELECT 
        timestamp,
        temperature,
        humidity,
        rainfall_1h,
        rainfall_24h,
        wind_speed,
        weather_condition
      FROM weather_data
      WHERE location_id = $1
      AND timestamp >= NOW() - INTERVAL '${interval}'
      ORDER BY timestamp ASC
    `;
    
    const result = await pool.query(query, [id]);
    
    res.json({
      success: true,
      period,
      count: result.rows.length,
      data: result.rows
    });
    
  } catch (error) {
    console.error('Error fetching weather history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch weather history'
    });
  }
});

module.exports = router;
```

Create `routes/risk.js`:
```javascript
const express = require('express');
const router = express.Router();
const pool = require('../config/database');

/**
 * GET /api/locations/:id/risk-history
 * Get risk assessment history
 */
router.get('/:id/risk-history', async (req, res) => {
  try {
    const { id } = req.params;
    const { period = '7d' } = req.query;
    
    const intervalMap = {
      '24h': '24 hours',
      '7d': '7 days',
      '30d': '30 days'
    };
    
    const interval = intervalMap[period] || '7 days';
    
    const query = `
      SELECT 
        timestamp,
        risk_level,
        risk_score,
        factors,
        rainfall_24h,
        rainfall_72h
      FROM risk_assessments
      WHERE location_id = $1
      AND timestamp >= NOW() - INTERVAL '${interval}'
      ORDER BY timestamp ASC
    `;
    
    const result = await pool.query(query, [id]);
    
    res.json({
      success: true,
      period,
      count: result.rows.length,
      data: result.rows
    });
    
  } catch (error) {
    console.error('Error fetching risk history:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch risk history'
    });
  }
});

module.exports = router;
```

Create `routes/dashboard.js`:
```javascript
const express = require('express');
const router = express.Router();
const pool = require('../config/database');

/**
 * GET /api/dashboard/summary
 * Get dashboard summary stats
 */
router.get('/summary', async (req, res) => {
  try {
    // Total locations
    const locationsCount = await pool.query(
      'SELECT COUNT(*) as count FROM locations'
    );
    
    // Risk distribution (latest for each location)
    const riskDist = await pool.query(`
      SELECT 
        risk_level,
        COUNT(*) as count
      FROM (
        SELECT DISTINCT ON (location_id) 
          location_id, risk_level
        FROM risk_assessments
        ORDER BY location_id, timestamp DESC
      ) latest_risks
      GROUP BY risk_level
    `);
    
    // Format risk distribution
    const riskDistribution = {
      CRITICAL: 0,
      HIGH: 0,
      MODERATE: 0,
      LOW: 0
    };
    
    riskDist.rows.forEach(row => {
      riskDistribution[row.risk_level] = parseInt(row.count);
    });
    
    // Last update time
    const lastUpdate = await pool.query(`
      SELECT MAX(timestamp) as last_update 
      FROM weather_data
    `);
    
    res.json({
      success: true,
      data: {
        totalLocations: parseInt(locationsCount.rows[0].count),
        riskDistribution,
        lastUpdate: lastUpdate.rows[0].last_update
      }
    });
    
  } catch (error) {
    console.error('Error fetching dashboard summary:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch dashboard summary'
    });
  }
});

module.exports = router;
```

### Step 4: Register Routes in server.js

Update `server.js`:
```javascript
const express = require('express');
const cors = require('cors');
const scheduler = require('./services/scheduler');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
const locationsRoutes = require('./routes/locations');
const weatherRoutes = require('./routes/weather');
const riskRoutes = require('./routes/risk');
const dashboardRoutes = require('./routes/dashboard');

app.use('/api/locations', locationsRoutes);
app.use('/api/locations', weatherRoutes);
app.use('/api/locations', riskRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date() });
});

// Root route
app.get('/', (req, res) => {
  res.json({ 
    message: 'Flood Alert System API',
    version: '1.0.0',
    endpoints: [
      'GET /api/locations',
      'GET /api/locations/:id',
      'GET /api/locations/:id/weather-history',
      'GET /api/locations/:id/risk-history',
      'GET /api/dashboard/summary'
    ]
  });
});

// Start scheduler
scheduler.start();

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📡 API available at http://localhost:${PORT}`);
});
```

**✅ Day 3-4 Complete! REST API built!**

---

## DAY 5-6: TEST API WITH POSTMAN (3-4 hours)

### Day 5: Install Postman & Create Tests

1. **Download Postman:** https://www.postman.com/downloads/
2. **Create new Collection:** "Flood Alert API"

### Test Each Endpoint:

**1. GET All Locations**
```
GET http://localhost:5000/api/locations
```
Expected: List of all 15 locations with current risk

**2. GET Single Location**
```
GET http://localhost:5000/api/locations/1
```
Expected: Wellampitiya details with weather and risk

**3. GET Weather History**
```
GET http://localhost:5000/api/locations/1/weather-history?period=7d
```
Expected: 7 days of weather data

**4. GET Risk History**
```
GET http://localhost:5000/api/locations/1/risk-history?period=7d
```
Expected: 7 days of risk assessments

**5. GET Dashboard Summary**
```
GET http://localhost:5000/api/dashboard/summary
```
Expected: Total locations, risk distribution, last update

### Day 6: Error Testing & Edge Cases

Test error scenarios:
- Invalid location ID: `GET /api/locations/999`
- Invalid period: `GET /api/locations/1/weather-history?period=invalid`
- Missing parameters

Fix any bugs found!

**✅ Day 5-6 Complete! API fully tested!**

---

## DAY 7: DOCUMENTATION & CLEANUP (2-3 hours)

### Step 1: Create API Documentation

Create `API_DOCUMENTATION.md`:
```markdown
# Flood Alert System - API Documentation

Base URL: `http://localhost:5000/api`

## Endpoints

### 1. Get All Locations
**GET** `/locations`

Returns list of all monitored locations with current risk level.

**Response:**
\`\`\`json
{
  "success": true,
  "count": 15,
  "data": [
    {
      "id": 1,
      "name": "Wellampitiya",
      "district": "Colombo",
      "latitude": 6.9497,
      "longitude": 79.9258,
      "elevation": 3,
      "risk_level": "MODERATE",
      "risk_score": 4
    }
  ]
}
\`\`\`

### 2. Get Location Details
**GET** `/locations/:id`

Returns detailed information for specific location.

**Parameters:**
- `id` (path) - Location ID

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "location": { ... },
    "currentWeather": { ... },
    "currentRisk": { ... }
  }
}
\`\`\`

### 3. Get Weather History
**GET** `/locations/:id/weather-history`

Returns historical weather data for charts.

**Parameters:**
- `id` (path) - Location ID
- `period` (query) - Time period: `24h`, `7d`, `30d` (default: `7d`)

### 4. Get Risk History
**GET** `/locations/:id/risk-history`

Returns historical risk assessments.

**Parameters:**
- `id` (path) - Location ID
- `period` (query) - Time period: `24h`, `7d`, `30d` (default: `7d`)

### 5. Get Dashboard Summary
**GET** `/dashboard/summary`

Returns overview statistics for dashboard.

**Response:**
\`\`\`json
{
  "success": true,
  "data": {
    "totalLocations": 15,
    "riskDistribution": {
      "CRITICAL": 0,
      "HIGH": 2,
      "MODERATE": 5,
      "LOW": 8
    },
    "lastUpdate": "2025-11-10T14:30:00Z"
  }
}
\`\`\`

## Error Responses

All endpoints return errors in this format:

\`\`\`json
{
  "success": false,
  "error": "Error message here"
}
\`\`\`

**Status Codes:**
- `200` - Success
- `404` - Resource not found
- `500` - Server error
```

### Step 2: Update README

Update `README.md`:
```markdown
# Flood Alert & Monitoring System - Backend

## Week 2 Progress ✅

- [x] Risk calculation algorithm implemented
- [x] Automated risk assessment every 30 minutes
- [x] Complete REST API with 5 endpoints
- [x] Tested with Postman
- [x] API documentation written

## API Endpoints

See [API_DOCUMENTATION.md](./API_DOCUMENTATION.md) for complete API reference.

## Running the Project

\`\`\`bash
npm run dev
\`\`\`

API will be available at `http://localhost:5000`

## Testing

Import Postman collection from `/postman` folder for testing all endpoints.

## Next Steps (Week 3)

- [ ] React frontend setup
- [ ] Basic dashboard
- [ ] Connect to API
```

### Step 3: Git Commit

```bash
git add .
git commit -m "Week 2 complete: Risk calculation + REST API"
git push
```

**✅ Day 7 Complete! Week 2 DONE!**

---

## ✅ WEEK 2 CHECKLIST

- [ ] Risk calculation service created
- [ ] Risk rules configuration file
- [ ] Risk calculator integrated with scheduler
- [ ] Automated risk calculation every 30 minutes
- [ ] 5 REST API endpoints created:
  - [ ] GET /api/locations
  - [ ] GET /api/locations/:id
  - [ ] GET /api/locations/:id/weather-history
  - [ ] GET /api/locations/:id/risk-history
  - [ ] GET /api/dashboard/summary
- [ ] All endpoints tested with Postman
- [ ] API documentation written
- [ ] Code committed to GitHub
- [ ] README updated

**If you checked all boxes: WEEK 2 CRUSHED! 🎉**

---

## TROUBLESHOOTING

**Issue: Risk scores always 0**
- Check weather data exists: `SELECT * FROM weather_data LIMIT 1;`
- Check rainfall aggregates are calculated
- Verify elevation data in locations table

**Issue: API returns empty data**
- Make sure scheduler has run at least once
- Check database has risk_assessments entries
- Verify location IDs are correct (1-15)

**Issue: Postman connection refused**
- Verify server is running: `npm run dev`
- Check port 5000 is not in use
- Confirm firewall allows localhost connections

---

## NEXT WEEK PREVIEW

Week 3 you'll learn React and build the dashboard!
- React crash course
- Create React app
- Fetch data from YOUR API
- Display on dashboard

**Take a break, you earned it! Week 2 = DONE! 💪**
